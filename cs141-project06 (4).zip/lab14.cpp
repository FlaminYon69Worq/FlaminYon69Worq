/*lab14.cpp*/
//
// Author: David Mendoza
//
// An intro to ClassReg class, and project 06.
//
#include <iostream>
#include <string>
#include "classreg.h"
using namespace std;

int main()
{
  ClassReg classreg; // our object for handling class enrollment
  string name;
  int capacity;
  string netid = "";
  int priority = 1;

  cout << "Enter class name>" << endl;
  cin >> name;
  classreg.setName(name);
  
  
  cout << "Enter class capacity>" << endl;
  cin >> capacity;
  classreg.setCapacity(capacity);
  //cout << classreg.getCapacity() << endl;
  
  cout << "Enter a student name to enroll (# to stop)>" << endl;
  cin >> netid;
  
  while (netid != "#") {
    
    if (classreg.numEnrolled() < classreg.getCapacity()) {
      classreg.enrollStudent(netid);
      cout << "Student '" << netid << "' was enrolled" << endl;
    }
    
    else {
      classreg.waitlistStudent(netid, 1);
      cout << "Student '" << netid << "' added to waitlist" << endl;
    }
    
    cout << "Enter a student name to enroll (# to stop)>" << endl;
    cin >> netid;
  }
  
  cout << classreg.getName() << endl;
  cout << "capacity: " << classreg.getCapacity() << endl;
  
  cout << "enrolled: ";
  int i;
  for (i = 0; i < classreg.numEnrolled(); i++) {
    cout << classreg.retrieveEnrolledStudent(i) << " ";
  }
  cout << endl;
  
  cout << "waitlisted: ";
  for (i = 0; i < classreg.numWaitlisted(); i++) {
    classreg.retrieveWaitlistedStudent(i, netid, priority);
    cout << netid << " ";
  }
  cout << endl;
  
    
  return 0;
}
  
  
