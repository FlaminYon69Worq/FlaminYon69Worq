/*main.cpp*/
//
// Author: David Mendoza, UIC, Spring 2021
//
// Project Due Date: 4/30/2021, 11:59 PM

// Project Overview: Classes - implement a simple class registration system for CS classes.

#include <iostream>
#include <fstream>
#include <string>
#include "classreg.h"
using namespace std;

void inputFile(ifstream infile, ClassReg classes[]) {
  string tempStr;
  int tempInt;
  //ifstream infile;
  for (int i = 0; i < 5; i++) {
    infile >> tempStr;
    classes[i].setName(tempStr);
    infile >> tempInt;
    classes[i].setCapacity(tempInt);
    // loop until see a #
    infile >> tempStr;
    while (tempStr != "#"){
      infile >> tempStr;
         classes[i].enrollStudent(tempStr); 
    }
    infile >> tempStr;
    while (tempStr != "#"){
      infile >> tempStr >> tempInt;
         classes[i].waitlistStudent(tempStr, tempInt); 
    }
  }
}

void HelpCommand(){
  cout << "stats" << endl << "list class" << "increase class capacity" << endl << "enroll class netid" << endl
  << "waitlist class netid priority" << endl << "process filename" << endl << "output filename" << endl << "quit" << endl;
}

// void StatsFunction(ClassReg classes[]){
//   for (int i = 0; i < 5; i++) {
//     cout << classes[i].numEnrolled();
//   }
// }

int main()
{
  cout << "**CS Enrollment System**" << endl;
  ClassReg classes; // cs111, cs141, cs151, cs211, cs251

  string filename = "enrollments.txt";
  cout << "Enter enrollments filename> " << endl;
  //cin >> filename;
  
  ifstream infile;
  infile.open(filename);

  // file checker opener
  if (!infile.good())  // file is NOT good, i.e. could not be opened:
  {
    cout << "**Error: unable to open enrollments file '" << filename << "'" << endl;
    return 0;  // return now since we cannot continue without input file
  }
  
  inputFile(infile, classes);
  
//   cout << endl;
//   string command = "";
//   cout << "Enter a command (help for more info, quit to stop)>" << endl;
//   cin >> command;
  
//   while (command != "quit") {
    
//     if (command == "h" || command == "help") { //done
//       HelpCommand();
//     }
    
//     else if(command == "s" || command == "stats") {
//       StatsFunction(ClassReg classes);
//       cout << "Stats" << endl;
//     }
    
//     else if(command == "l" || command == "list") {
//       cout << "list" << endl;
//     }
    
//     else if(command == "i" || command == "increase") {
//       cout << "increase" << endl;
//     }
    
//     else if(command == "e" || command == "enroll") {
//       cout << "enroll" << endl;
//     }
    
//     else if(command == "w" || command == "waitlist") {
//       cout << "waitlist" << endl;
//     }
    
//     else if(command == "p" || command == "process") {
//       cout << "process" << endl;
//     }
    
//     else if(command == "o" || command == "output") {
//       cout << "output" << endl;
//     }
    
//     else if (command == "q") {
//       break;
//     }
    
//     else {     
//       cout << "** Invalid command, try again..." << endl;
//     }
    
//     cout << endl;
//     cout << "Enter a command (help for more info, quit to stop)>" << endl;
//     cin >> command;
//   }
  
  cout << endl;
  cout << "**Done**" << endl; 
  return 0;
}
  
  
